﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp3.datos;
using WindowsFormsApp3.negocio;


namespace WindowsFormsApp3.presentacion.alumno
{
    public partial class FrmVerAlumnos : Form
    {
        public FrmVerAlumnos()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            NegocioAlumno negocioAlumno = new NegocioAlumno();
            EntidadAlumno alumno = new EntidadAlumno();

            alumno.Dni = txtdni.Text;
            
            int num = negocioAlumno.ActulizarAlumnoN(alumno);

            if (num != 0)
            {
                MessageBox.Show("Operacion Satisfactoria");
                txtdni.Text = "";
                
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            NegocioAlumno negocioAlumno = new NegocioAlumno();
            EntidadAlumno alumno = new EntidadAlumno();

           
            int num = negocioAlumno.ActulizarAlumnoN(alumno);

            
        }

        private void FrmVerAlumnos_Load(object sender, EventArgs e)
        {

        }
    }
}
