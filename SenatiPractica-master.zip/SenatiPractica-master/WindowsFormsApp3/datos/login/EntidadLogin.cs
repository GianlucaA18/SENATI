﻿namespace WinFormsApp2
{
    internal class EntidadLogin
    {
        public string Usuario { get; set; }
        public string Contrasenia { get; set; }
    }
}
