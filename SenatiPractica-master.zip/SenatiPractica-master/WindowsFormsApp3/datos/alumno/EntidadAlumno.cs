﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp3.datos
{
    internal class EntidadAlumno
    {
        public String Dni { get; set; }
        public String Nombres { get; set; }
        public String Apellidos { get; set; }

    }
}
